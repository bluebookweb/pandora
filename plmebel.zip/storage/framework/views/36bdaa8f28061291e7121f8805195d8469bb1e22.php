<?php $__env->startSection('title', 'Fillings'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end mb-4">
        <a href="<?php echo e(route('fillings.create')); ?>" class="btn bg-gradient-primary m-0 ms-2">Add filling</a>
    </div>
    <div class="card">
        <?php if($products->total()): ?>
            <div class="table-responsive">
                <table class="table align-items-center mb-0">
                    <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Name</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Background
                            of filling
                        </th>
                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                            Thumbnail of filling
                        </th>
                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                            Is Image
                        </th>
                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                            Action
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('fillings.edit', $item)); ?>"
                                   class="text-xs font-weight-bold mb-0"><?php echo e($item->name); ?></a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('fillings.edit', $item)); ?>" class="text-xs font-weight-bold mb-0">
                                    <?php if(empty($item->background)): ?>
                                        <p class="categories-bg"
                                           style="background-image: url(<?php echo e(asset('img/default-thumbnail.jpg')); ?>)"></p>
                                    <?php else: ?>
                                        <p class="categories-bg"
                                           style="background-image: url(<?php echo e(Storage::url($item->background)); ?>)"></p>
                                    <?php endif; ?>
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('fillings.edit', $item)); ?>" class="text-xs font-weight-bold mb-0">
                                    <?php if(empty($item->thumb)): ?>
                                        <p class="categories-bg"
                                           style="background-image: url(<?php echo e(asset('img/default-thumbnail.jpg')); ?>)"></p>
                                    <?php else: ?>
                                        <p class="categories-bg"
                                           style="background-image: url(<?php echo e(Storage::url($item->thumb)); ?>)"></p>
                                    <?php endif; ?>
                                </a>
                            </td>
                            <td class="align-middle text-center text-sm">
                            <span
                                class="badge badge-sm <?php if($item->is_img == 1): ?> badge-success <?php else: ?> badge-danger <?php endif; ?>">is image</span>
                            </td>
                            <td class="align-middle form-action-block">
                                <a href="<?php echo e(route('fillings.edit', $item)); ?>"
                                   class="text-secondary font-weight-bold text-xs" data-toggle="tooltip"
                                   data-original-title="Edit user">
                                    <i class="fas fa-user-edit"></i>
                                </a>
                                <form action="<?php echo e(route('fillings.destroy', $item)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button onclick="return confirmation()"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-products">
                <span>Any products displayed yet.</span>
            </div>
        <?php endif; ?>
    </div>
    <div class="admin-pagination">
        <?php echo e($products->links()); ?>

    </div>
    <?php if(Session::has('msg')): ?>
        <div class="error-block">
            <?php echo e(Session::get('msg')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        function confirmation() {
            return confirm('Confirm to delete?');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OS\OpenServer\domains\plmebel\resources\views/admin/fillings/index.blade.php ENDPATH**/ ?>