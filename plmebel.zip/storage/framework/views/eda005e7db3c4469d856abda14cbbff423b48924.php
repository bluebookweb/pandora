<?php $__env->startSection('title', 'Edit door division'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-9 col-12 mx-auto">
            <?php echo Form::open(['route' => ['door-division.update', $doorDivision], 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="card card-body mt-4">
                <h6 class="mb-0" style="text-align: center;">New door division</h6>
                <hr class="horizontal dark my-3">
                <label for="image" class="form-label">Image of division</label>
                <div class="form-control mb-4">
                    <img src="<?php echo e(Storage::url($doorDivision->image)); ?>" alt="" width="200px">
                    <input type="file"
                           name="image"
                           id="image">
                </div>
                <label for="divide" class="form-label">Divisions number</label>
                <input type="number"
                       class="form-control"
                       name="divide"
                       value="<?php echo e(old('divide') ? old('divide') : $doorDivision->divide); ?>"
                       id="divide">
                <?php $__errorArgs = ['divide'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error-msg"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="d-flex justify-content-end mt-4">
                    <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Save</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OS\OpenServer\domains\plmebel\resources\views/admin/doordivisions/edit.blade.php ENDPATH**/ ?>