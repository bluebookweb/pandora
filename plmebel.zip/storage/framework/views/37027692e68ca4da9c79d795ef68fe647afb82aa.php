<?php $__env->startSection('title', 'New filling'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-9 col-12 mx-auto">
            <form action="<?php echo e(route('fillings.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card card-body mt-4">
                    <h6 class="mb-0" style="text-align: center;">New filling page</h6>
                    <hr class="horizontal dark my-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text"
                           class="form-control"
                           name="name"
                           value="<?php echo e(old('name')); ?>"
                           id="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-msg"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="background" class="mt-4 form-label">Background of filling</label>
                    <div class="form-control">
                        <input type="file"
                               name="background"
                               id="background">
                    </div>
                    <?php $__errorArgs = ['background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-msg"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="thumb" class="mt-4 form-label">Thumbnail of filling</label>
                    <div class="form-control">
                        <input type="file"
                               name="thumb"
                               id="thumb">
                    </div>
                    <?php $__errorArgs = ['thumb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-msg"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="row mt-4">
                        <div class="col-6 col-md-6">
                            <div class="form-group">
                                <label for="is_img">
                                    Is Image
                                </label>
                                <p class="form-text text-muted text-xs ms-1">
                                    Click to switch the value.
                                </p>
                                <div class="form-check form-switch ms-1">
                                    <input class="form-check-input" name="is_img" type="checkbox" id="is_img">
                                    <label class="form-check-label" for="is_img"></label>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-md-6">
                            <div class="form-group">
                                <label for="is_mirror">
                                    Is Mirror
                                </label>
                                <p class="form-text text-muted text-xs ms-1">
                                    Click to switch the value.
                                </p>
                                <div class="form-check form-switch ms-1">
                                    <input class="form-check-input" name="is_mirror" type="checkbox" id="is_mirror">
                                    <label class="form-check-label" for="is_mirror"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label for="available">Available for</label>
                    <div class="row">
                        <div class="col-2 d-flex">
                            <input type="checkbox" name="available_for[]" value="doors" id="doors">
                            <label for="doors">doors</label>
                        </div>
                        <div class="col-2 d-flex">
                            <input type="checkbox" name="available_for[]" value="gable" id="gable">
                            <label for="gable">gable</label>
                        </div>
                        <div class="col-2 d-flex">
                            <input type="checkbox" name="available_for[]" value="impact" id="impact">
                            <label for="impact">impact</label>
                        </div>
                    </div>
                    <?php $__errorArgs = ['available_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-msg"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="d-flex justify-content-end mt-4">
                        <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/admin/jquery-3.3.1.min.js')); ?>"></script>
    <script>
        $(function(){
            var requiredCheckboxes = $('.row :checkbox[required]');
            requiredCheckboxes.change(function(){
                if(requiredCheckboxes.is(':checked')) {
                    requiredCheckboxes.removeAttr('required');
                } else {
                    requiredCheckboxes.attr('required', 'required');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OS\OpenServer\domains\plmebel\resources\views/admin/fillings/create.blade.php ENDPATH**/ ?>