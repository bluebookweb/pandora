<?php $__env->startSection('title', 'Edit position'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-9 col-12 mx-auto">
            <?php echo Form::open(['route' => ['inventory.update', $inventory], 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="card card-body mt-4">
                <h6 class="mb-0" style="text-align: center;">New inventory page</h6>
                <hr class="horizontal dark my-3">
                <label for="name" class="form-label">Name</label>
                <input type="text"
                       class="form-control"
                       value="<?php echo e(old('name') ? old('name') : $inventory->name); ?>"
                       name="name"
                       id="name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error-msg"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="row mt-2">
                    <div class="col-6 col-md-6">
                        <div class="form-group">
                            <label for="price">Price</label>
                            <input name="price"
                                   value="<?php echo e(old('price') ? old('price') : $inventory->price); ?>"
                                   type="number"
                                   id="price"
                                   class="form-control">
                        </div>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-msg"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 col-md-6">
                        <div class="form-group">
                            <label for="width">Width (mm)</label>
                            <input name="width"
                                   value="<?php echo e(old('width') ? old('width') : $inventory->width); ?>"
                                   type="number"
                                   id="width"
                                   class="form-control">
                        </div>
                        <?php $__errorArgs = ['width'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-msg"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 col-md-6">
                        <div class="form-group">
                            <label for="height">Height (mm)</label>
                            <input name="height"
                                   value="<?php echo e(old('height') ? old('height') : $inventory->height); ?>"
                                   type="number"
                                   id="height"
                                   class="form-control">
                        </div>
                        <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-msg"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 col-md-6">
                        <div class="form-group">
                            <label for="depth">Depth (mm)</label>
                            <input name="depth"
                                   value="<?php echo e(old('depth') ? old('depth') : $inventory->depth); ?>"
                                   type="number"
                                   id="depth"
                                   class="form-control">
                        </div>
                        <?php $__errorArgs = ['depth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-msg"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <label for="thumb" class="mt-2 form-label">Thumbnail of inventory</label>
                <div class="form-control">
                    <img src="<?php echo e(Storage::url($inventory->thumb)); ?>" width="200px" alt="">
                    <input type="file" name="thumb" id="thumb">
                </div>
                <label for="front" class="mt-2 form-label">Image of front</label>
                <div class="form-control">
                    <img src="<?php echo e(Storage::url($inventory->front)); ?>" width="200px" alt="">
                    <input type="file" name="front" id="front">
                </div>
                <label for="top" class="mt-2 form-label">Image of top</label>
                <div class="form-control">
                    <img src="<?php echo e(Storage::url($inventory->top)); ?>" width="200px" alt="">
                    <input type="file" name="top" id="top">
                </div>

                <label for="product_code" class="mt-4 form-label">Product code</label>
                <input type="text"
                       value="<?php echo e(old('product_code') ? old('product_code') : $inventory->product_code); ?>"
                       class="form-control"
                       name="product_code"
                       id="product_code">
                <?php $__errorArgs = ['product_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error-msg"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div id="gable_position_block" class="mt-3 mb-3">
                    <label for="gable_position">Category</label>
                    <select name="category_id" id="gable_position" class="form-control">
                        <option selected disabled value="">Select the inventory category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"
                            <?php if($inventory->category_id == $category->id): ?>
                                selected
                            <?php endif; ?>
                            ><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <label for="available">Products fits to</label>
                <div class="row">
                    <div class="col-2 d-flex">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->name !== $inventory->name): ?>
                            <input type="checkbox"
                                   name="fits_in[]"
                                   <?php if(in_array($product->name, $inventory->fits_in)): ?>
                                   checked
                                   <?php endif; ?>
                                   value="<?php echo e($product->name); ?>"
                                   id="<?php echo e($product->name); ?>">
                            <label for="<?php echo e($product->name); ?>"><?php echo e($product->name); ?></label>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="d-flex justify-content-end mt-4">
                    <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Save</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OS\OpenServer\domains\plmebel\resources\views/admin/inventory/edit.blade.php ENDPATH**/ ?>